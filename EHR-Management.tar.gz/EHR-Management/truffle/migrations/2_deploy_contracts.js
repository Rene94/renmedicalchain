const Adoption = artifacts.require("MedicalRecordSystem");

module.exports = function(deployer) {
    deployer.deploy(Adoption);
};
