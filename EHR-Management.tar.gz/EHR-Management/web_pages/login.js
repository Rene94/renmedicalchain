function loginAsPatient() {
    window.location.href = "http://localhost/patient/";
}

function loginAsMedic() {
    window.location.href = "http://localhost/medic/";
}
